
package com.mycompany.quanlydemo1;

public class Quanlydemo1 {

    public static void main(String[] args) {       
        // gọi jv swing 
        JFQuanly jfs = new JFQuanly();
       jfs.show();
    }
}
